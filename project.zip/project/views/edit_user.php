<?php
session_start();
include '../includes/db.php'; // Database connection

// Ensure the user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Check if user ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("User ID is missing!");
}

$user_id = $_GET['id'];

// Fetch user data
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// If user not found
if (!$user) {
    die("User not found!");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $user_role = $_POST['user_role'];

    $update_sql = "UPDATE users SET full_name=?, email=?, user_role=? WHERE id=?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sssi", $full_name, $email, $user_role, $user_id);

    if ($update_stmt->execute()) {
        header("Location: manage_users.php?success=User updated successfully");
        exit();
    } else {
        echo "Error updating user!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; }
        .container { width: 40%; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        .form-group { display: flex; flex-direction: column; align-items: flex-start; margin-bottom: 15px; }
        label { font-weight: bold; margin-bottom: 5px; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
        .buttons { display: flex; justify-content: space-between; margin-top: 20px; }
        .btn { padding: 10px 15px; border-radius: 5px; text-decoration: none; color: white; cursor: pointer; border: none; width: 48%; text-align: center; }
        .save { background: green; }
        .cancel { background: gray; }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit User</h2>
    <form method="POST">
        <div class="form-group">
            <label>Full Name:</label>
            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        </div>

        <div class="form-group">
            <label>User Role:</label>
            <select name="user_role" required>
                <option value="admin" <?php if ($user['user_role'] == 'admin') echo 'selected'; ?>>Admin</option>
                <option value="customer" <?php if ($user['user_role'] == 'customer') echo 'selected'; ?>>Customer</option>
                <option value="delivery_agent" <?php if ($user['user_role'] == 'delivery_agent') echo 'selected'; ?>>Delivery Agent</option>
            </select>
        </div>

        <div class="buttons">
            <button type="submit" class="btn save">💾 Save Changes</button>
            <a href="manage_users.php" class="btn cancel">❌ Cancel</a>
        </div>
    </form>
</div>

</body>
</html>