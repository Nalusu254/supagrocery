<?php
session_start();
include '../includes/db.php';

// Ensure user is logged in
if (!isset($_SESSION["user_id"])) {
    echo "<script>alert('Please login to proceed to checkout.'); window.location='login.php';</script>";
    exit;
}

$user_id = $_SESSION["user_id"];

// Fetch cart items for the logged-in user
$sql = "SELECT id, product_name, quantity, price FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($sql);

$total_price = 0;

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Calculate total price
    while ($item = $result->fetch_assoc()) {
        $total_price += $item["price"] * $item["quantity"];
    }
} else {
    echo "<p style='color: red;'>Error: " . $conn->error . "</p>";
}

// Handle order placement
if (isset($_POST['place_order'])) {
    $order_sql = "INSERT INTO orders (user_id, total_price, status, paid) VALUES (?, ?, 'pending', 0)";
    $order_stmt = $conn->prepare($order_sql);
    if ($order_stmt) {
        $order_stmt->bind_param("id", $user_id, $total_price);
        if ($order_stmt->execute()) {
            echo "<script>alert('Order placed successfully!'); window.location='my_orders.php';</script>";
        } else {
            echo "<p style='color: red;'>Error: " . $conn->error . "</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; text-align: center; }
        .container { max-width: 800px; margin: auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); }
        h2 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: center; }
        th { background: #28a745; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .btn { padding: 10px 20px; background: blue; color: white; text-decoration: none; border-radius: 5px; }
        .btn:hover { background: darkblue; }
    </style>
</head>
<body>
    <div class="container">
        <h2>🧾 Checkout</h2>
        <form method="POST">
            <p>Total Amount: <strong><?php echo number_format($total_price, 2); ?> Ksh</strong></p>
            <button type="submit" name="place_order" class="btn">Place Order</button>
        </form>
    </div>
</body>
</html>