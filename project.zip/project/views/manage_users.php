<?php
session_start();
include '../includes/db.php'; // Database connection

// Ensure the user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Fetch all users
$sql = "SELECT id, full_name, email, user_role FROM users ORDER BY user_role ASC";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; background-color: #f4f4f4; }
        .container { width: 90%; margin: auto; background: white; padding: 20px; border-radius: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background: #007BFF; color: white; }
        .btn { padding: 8px 12px; margin: 5px; border-radius: 5px; text-decoration: none; color: white; cursor: pointer; }
        .edit { background: green; }
        .delete { background: red; }
        .return { background: gray; }
    </style>
</head>
<body>

<div class="container">
    <h2>Manage Users</h2>
    <a href="admin_dashboard.php" class="btn return">⬅ Return to Dashboard</a>
    
    <table>
        <tr>
            <th>User ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
        <?php while ($user = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $user['id']; ?></td>
            <td><?php echo htmlspecialchars($user['full_name']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
            <td><?php echo ucfirst($user['user_role']); ?></td>
            <td>
                <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn edit">✏ Edit</a>
                <a href="delete_user.php?id=<?php echo $user['id']; ?>" class="btn delete" onclick="return confirm('Are you sure you want to delete this user?');">🗑 Delete</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>

</body>
</html>