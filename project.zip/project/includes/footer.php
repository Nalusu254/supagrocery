<footer>
    <p>&copy; 2025 Supa Grocery. All rights reserved.</p>
</footer>
</body>
</html>